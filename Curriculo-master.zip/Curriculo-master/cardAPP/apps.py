from django.apps import AppConfig


class CardappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cardAPP'
