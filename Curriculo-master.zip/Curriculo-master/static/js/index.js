// console.log('index.js loaded')
// ReactDOM.render(
//     <h1>Carregou index.js</h1>,
//     document.getElementById("root")
// )
// --------------------------------------------------------------------
// ReactDOM.render(
//     <div>
//         <Navbar />
//     </div>,
//     document.getElementById("root")
// )
// --------------------------------------------------------------------
// ReactDOM.render(navbar, document.getElementById("root"))
// --------------------------------------------------------------------
// ReactDOM.createRoot(document.getElementById("root")).render(navbar)
// --------------------------------------------------------------------
// REACT 18
// const root = ReactDOM.createRoot(document.getElementById("root"))
// root.render(navbar)

const root = ReactDOM.createRoot(document.getElementById("root"))
root.render(<Page />)