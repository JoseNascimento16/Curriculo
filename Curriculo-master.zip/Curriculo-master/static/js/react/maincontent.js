function MainContent(){
    return(
        <div className="div-main-content">
            <img className="maincontent-img" src="/static/img/Curriculo-Jose-Nascimento.png" alt=""></img>
            <div className="linkedin-div">
                <img className="linkedin-img" src="/static/img/linkedin-icon.png" alt=""></img>
            </div>
        </div>
    )
}