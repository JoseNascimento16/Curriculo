function Footer(){
    return(
        <footer>
            <div className="div-footer">
                <small>© 2023 Jose development. All rights reserved.</small>
            </div>
        </footer>
    )
}