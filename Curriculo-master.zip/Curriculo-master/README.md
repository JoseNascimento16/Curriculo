<h1 align="center">Currículo online</h1>

## Sobre ![pin-img](https://user-images.githubusercontent.com/110631271/215866770-755c96a6-17fa-4a7c-9c05-23693843f01c.png)

Este projeto é somente o meu currículo que disponibilizei online, em PDF (inglês e português) e que pode ser baixado pelo navegador.<br>
Ele possui links clicáveis que redirecionam para meus perfis no Linkedin e Github.<br>
Hospedei no pythonanywhere mesmo por questões de praticidade e porque ele utiliza um pouco de backend.

Disponível em: https://josenascimento.pythonanywhere.com/

